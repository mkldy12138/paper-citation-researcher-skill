# Output Schema

## `citing_papers.csv`

- `dedupe_key`: DOI-based or normalized-title key used for merging platforms.
- `source_platforms`: semicolon-separated platforms where the citing paper was found.
- `source_record_ids`: semicolon-separated source IDs or source URLs.
- `citing_title`: title of the citing paper.
- `citing_authors`: author string from the source platform.
- `publication_year`: publication year when available.
- `venue`: venue or source metadata string.
- `doi`: citing-paper DOI when available.
- `url`: landing page URL.
- `pdf_url`: direct PDF URL found by Google Scholar.
- `open_access_pdf_url`: open PDF URL from Semantic Scholar.
- `citation_count`: citation count for the citing paper. Google Scholar and Semantic Scholar rows always provide this value; use `0` when the source has no citation count for the paper.
- `semantic_scholar_paper_id`: Semantic Scholar paper ID.
- `google_scholar_cited_by_url`: Google Scholar cited-by URL when present.
- `arxiv_id`: arXiv external ID.
- `acl_id`: ACL Anthology external ID.
- `abstract`: Semantic Scholar abstract when available.

## `download_manifest.csv`

Includes all `citing_papers.csv` columns plus:

- `pdf_path`: local PDF path for successful downloads.
- `download_status`: `downloaded` or `failed`.
- `download_url`: final PDF URL used for a successful download.
- `failure_reason`: error details for failed downloads.

## `manual_download_todo.csv`

Includes failed download rows plus:

- `candidate_urls`: semicolon-separated URLs that were attempted or may help manual search.
- `expected_pdf_path`: preferred local path to save the manually downloaded PDF.
- `manual_pdf_path`: optional path to fill when the PDF is saved somewhere else.

The `analyze` command reads this file automatically and includes rows whose `manual_pdf_path` or `expected_pdf_path` points to an existing PDF.

## `citation_contexts.csv`

- `citing_title`: title of the citing paper.
- `pdf_path`: local PDF analyzed.
- `page`: 1-based PDF page number.
- `line_start` / `line_end`: line range in the extracted page text.
- `citation_marker`: numeric, author-year, title, or alias cue.
- `context`: extracted in-body citation context.
- `is_positive`: whether the context contains positive/affirmative language.
- `confidence`: heuristic confidence score.
- `reason`: cue type used to keep the context.
- `source_platforms`: source platforms inherited from metadata.
- `doi`: citing-paper DOI.
